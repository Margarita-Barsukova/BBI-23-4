﻿//Сделать абстрактный класс «Прыжки в воду» с обязательным полем «Название дисциплины», и от него наследников: «с 3м» и «с 5м».
//В каждом из классов переопределить название дисциплины (и выводить в начале таблицы).


using P1;
using IIIProjects.Serializers;

namespace P2
{

    public class Diver
    {
        private string _lastname;
        public string LastName => _lastname;

        private Jump[] _jumps;
        public Jump[] Jumps => _jumps;

        private double _totalscore;
        public double TotalScore => _totalscore;

        public Diver(string lastName, Jump[] jumps)
        {
            _lastname = lastName;
            _jumps = jumps;

            //Сразу же делаем так, что бы спортсмен при создании прыгал несколько раз
            foreach (var jump in Jumps)
                jump.Evaluate();

            CalculateTotalScore();
        }

        public double CalculateTotalScore()
        {
            foreach (var jump in Jumps)
                _totalscore += jump.TotalScore;

            _totalscore = Math.Round(TotalScore, 2);

            return TotalScore;
        }
    }
    public class Jump
    {
        private double _rate;
        public double Rate => _rate;

        private double[] Scores = new double[7];

        private double _totalscore;
        public double TotalScore => _totalscore;

        //Конструктор, который создаёт прыжок и автоматически назначает ему коэф.
        public Jump()
        {
            var random = new Random().Next(25, 36);
            _rate = (double)random / (double)10;
        }

        //Конструктор, который создаёт прыжок и куда подаётся коэф.
        public Jump(double rate)
        {
            _rate = rate;
        }

        //Результаты прыжка
        public void Evaluate()
        {
            for (int i = 0; i < 7; i++)
            {
                Scores[i] = new Random().Next(100, 601) / 100;
            }


            _shellSort(Scores);

            //Обнуление самой лучшей и худшей оценки
            Scores[0] = 0;
            Scores[6] = 0;

            double tempScore = 0;

            foreach (double score in Scores)
            {
                tempScore += score;
            }

            _totalscore = tempScore * Rate;

        }

        private static void _shellSort(double[] array)
        {
            int n = array.Length;
            int gap = n / 2;

            while (gap > 0)
            {
                for (int i = gap; i < n; i++)
                {
                    double temp = array[i];
                    int j;
                    for (j = i; j >= gap && array[j - gap] < temp; j -= gap)
                    {
                        array[j] = array[j - gap];
                    }
                    array[j] = temp;
                }
                gap /= 2;
            }
        }
    }
    public abstract class WaterJumps
    {
        public abstract string DisciplineName { get; set; }

        protected Diver[] Divers;

        public void Start(UniversalSerializer serializer)
        {
            _selectionSort(Divers);

            Console.WriteLine("Тип: " + DisciplineName);
            Console.WriteLine("Место\tФамилия спортсмена\tИтоговая оценка");

            //Сериализация в json-файл
            serializer.Serialize(Divers, "divers");

            //Парсинг из файла
            var parsedDivers = serializer.Deserialize<Diver[]>("divers", "");

            //Отображение по данным, спаршеным из файла
            int place = 1;
            foreach (var diver in parsedDivers)
            {
                Console.WriteLine($"{place}\t{diver.LastName}\t\t\t{diver.TotalScore}");
                place++;
            }
        }


        private void _selectionSort(Diver[] Array)
        {
            for (int i = 0; i < Array.Length - 1; i++)
            {
                int min = i;
                for (int j = i + 1; j < Array.Length; j++)
                {
                    if (Array[j].TotalScore > Array[min].TotalScore)
                    {
                        min = j;
                    }
                }
                Diver d = Array[i];
                Array[i] = Array[min];
                Array[min] = d;
                min = i;
            }
        }
    }
    internal class WaterJumps3m : WaterJumps
    {
        public override string DisciplineName { get; set; }

        public WaterJumps3m(Diver[] divers)
        {
            DisciplineName = "Прыжки 3 метра";
            Divers = divers;
        }
    }
    internal class WaterJumps5m : WaterJumps
    {
        public override string DisciplineName { get; set; }

        public WaterJumps5m(Diver[] divers)
        {
            DisciplineName = "Прыжки 5 метров";
            Divers = divers;
        }
    }
}