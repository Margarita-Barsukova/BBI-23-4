﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace IIIProjects.Serializers
{
    public class CustomXmlSerializer : UniversalSerializer
    {
        public override T? Deserialize<T>(string fileName, string filePath = "") where T : default
        {
            StreamReader reader = new StreamReader(filePath + fileName + ".xml");
            var s = new XmlSerializer(typeof(T));

            T result = (T)s.Deserialize(reader);
            reader.Dispose();

            return result;
        }

        public override void Serialize(object @object, string fileName, string filePath = "")
        {
            XmlSerializer serializer = new XmlSerializer(@object.GetType());
            StreamWriter writer = new StreamWriter(filePath + fileName + ".xml");
            serializer.Serialize(writer, @object);
            writer.Dispose();
        }
    }
}
